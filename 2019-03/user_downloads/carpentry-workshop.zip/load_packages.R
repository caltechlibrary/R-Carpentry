# Load needed packages into R environment

library(gridExtra) # ggplot
library(hexbin) # ggplot
library(tidyverse) # lesson 3 onwards
library(lubridate)
library(readr)
library(ggplot2)
library(dplyr)
library(magrittr)
library(tidyr)
library(knitr)
library(methods)