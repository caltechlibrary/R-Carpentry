# The file structure and needed files should be set up from zip file

# Download needed packages

install.packages("rmarkdown")
install.packages("tidyverse") # Download and install tidyverse
