## ---- math_trick
shoe_size <- 9
shoe_size_mod <- (((shoe_size * 5) + 50) * 20) + 1018 - 1979
shoe_size_mod