# Load needed packages into R environment

library(rmarkdown)
library(tidyverse)
library(magrittr)
library(knitr)
library(methods)